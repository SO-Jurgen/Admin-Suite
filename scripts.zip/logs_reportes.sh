#!/bin/bash
log="/var/log/adminsuite.log"
reporte="/adminsuitex/reportes"

op=99
while [ $op -ne 0 ]
do
	echo ""
	echo "*-*-* Logs y Reportes *-*-*"
	echo "1 - Ver logs de la app/SO"
	echo "2 - Buscar por patrón"
	echo "3 - Errores recientes"
	echo "4 - Exportar informe de errores (txt)"
	echo "0 - Volver"
	read -p "Ingrese una opción: " op

	case $op in
		1)
			echo ""
			echo "--- Ver Logs ---"
			echo "1 - Logs del Sistema Operativo"
			echo "2 - Logs de la Aplicación (WordPress)"
			read -p "Seleccione el tipo de log: " opcion_log

			case $opcion_log in
				1)
					echo "Mostrando las últimas 20 líneas del log del SO:"
					journalctl | tail -n 20 
					;;
				2)
					if sudo docker ps -a --filter name=wp | grep -q wp; then
						echo "Mostrando los últimos 20 logs del contenedor 'wp':"
						sudo docker logs wp --tail 20
					else
						echo "Error: El contenedor 'wp' no existe. Instale la aplicación primero."
						echo "$(date) - [ERROR] No se pudo mostrar los logs del Docker 'wp'." >> $log
					fi
					;;
				*)
					echo "Opción de log inválida."
					;;
			esac
			;;

		2)
			read -p "Palabra a buscar en el log del SO: " patron
			journalctl | grep -i "$patron"
			;;

		3)
			echo "Mostrando los últimos 20 errores del sistema:"
			journalctl | grep -i "error" | tail -n 20
			;;

		4)
			sudo mkdir -p "$reporte"
			archivo="informe_$(date +%Y%m%d).txt"
			ruta="$reporte/$archivo"
			journalctl | grep -i "error" > "$ruta" 
			echo "Informe exportado a: $ruta."
			echo "$(date) - Informe exportado ($ruta)" >> $log
			;;

		0) echo "Salida exitosa del menú de Logs y Reportes" ;;
		*) echo "Opción inválida." ;;
	esac
done
