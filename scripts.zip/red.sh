#!/bin/bash
log="/var/log/adminsuite.log"
reporte="/adminsuitex/reportes/red"

if ! which nmap 2>/dev/null; then
    sudo yum install -y nmap
fi

op=99
while [ $op -ne 0 ]
do
	echo ""
	echo "*-*-* Herramientas de Red *-*-*"
	echo "1 - Ping a host"
	echo "2 - Barrido simple de hosts activos"
	echo "3 - Servicios locales"
	echo "4 - Escaneo básico (nmap)"
	echo "5 - Informe de red"
	echo "0 - Volver"
	read -p "Ingrese una opción: " op

	case $op in
		1)
			read -p "Host o IP: " host
			ping $host
			echo "$(date) - Ping a $host" >> $log
			;;

		2)
			read -p "Red (ejemplo 192.168.1.0/24): " red
			nmap -sn $red
			echo "$(date) - Barrido de red $red" >> $log
			;;

		3)
			systemctl --type=service
			;;

		4)
			read -p "Host objetivo: " host
			nmap $host
			echo "$(date) - Escaneo nmap a $host" >> $log
			;;

		5)
			sudo mkdir -p "$reporte"
			archivo="informe_red_$(date +%Y%m%d).txt"
			ruta="$reporte/$archivo"
			ip a > "$ruta"
			echo "Informe guardado en $archivo"
			echo "$(date) - Informe de red creado ($ruta)." >> $log
			;;

		0) echo "Salida exitosa del menú de Red." ;;
		*) echo "Opción inválida." ;;
	esac
done

