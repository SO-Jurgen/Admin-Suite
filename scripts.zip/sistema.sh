#!/bin/bash
log="/var/log/adminsuite.log"

op=99
while [ $op -ne 0 ]
do
	echo ""
	echo "*-*-* Sistema *-*-*"
	echo "1 - Información del sistema"
	echo "2 - Espacio en disco"
	echo "3 - Servicios activos"
	echo "4 - Actualizar SO"
	echo "0 - Volver"
	read -p "Ingrese una opción: " op

	case $op in
		1)
			uname -a
			;;
		2)
			df -h
			;;
		3)
			echo "Mostrando servicios activos del sistema:"
			systemctl --type=service --state=running
			;;
		4)
			sudo yum check-update
			read -p "¿Desea continuar con la actualización? (s/n): " confirmar
			if [ "$confirmar" = "s" ] || [ "$confirmar" = "S" ]; then
				sudo yum update -y
				echo "¡Sistema actualizado!"
				echo "$(date) - Sistema actualizado" >> "$log"
			else
				echo "Actualización cancelada."
			fi
			;;
		0) echo "Salida exitosa del menú de Sistema." ;;
		*) echo "Opción inválida." ;;
	esac
done

