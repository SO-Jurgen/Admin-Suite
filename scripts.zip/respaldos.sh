#!/bin/bash
log="/var/log/adminsuite.log"
carpeta="/home"
destino="/adminsuitex/backups/diario"

op=99
while [ $op -ne 0 ]
do
	echo ""
	echo "*-*-* Respaldos *-*-*"
	echo "1 - Configurar cron"
	echo "2 - Ejecutar ahora"
	echo "3 - Ver últimos respaldos"
	echo "4 - Probar restauración"
	echo "0 - Volver"
	read -p "Ingrese una opción: " op

	case $op in
		1)
			echo "Abriendo cron..."
			echo "Ejemplo de línea para agregar:"
			echo "0 2 * * * tar -czf /root/respaldo_\$(date +\%Y\%m\%d).tar.gz /home"
			sudo crontab -e
			echo "$(date) - Cron configurado" >> $log
			;;

		2)
			sudo mkdir -p "$destino"
			nombre_archivo="respaldo_$(date +%Y%m%d).tar.gz"
			ruta="$destino/$nombre_archivo"
			sudo tar -czf "$ruta" "$carpeta"
			echo "Respaldo creado: $ruta"
			echo "$(date) - Respaldo manual creado ($ruta)" >> $log
			;;

		3)
			ls -l "$destino"/respaldo_*.tar.gz 2>/dev/null || echo "No hay respaldos todavía."
			;;

		4)
			read -p "Ingrese el nombre del archivo a restaurar (ej: respaldo_20251019.tar.gz): " archivo
			
			ruta_restaurar="$destino/$archivo"

			if [ -f "$ruta_restaurar" ]; then
				echo "Iniciando restauración de $archivo..."
				sudo tar -xzf "$ruta_restaurar" -C /
				echo "Restauración completada del archivo $archivo"
				echo "$(date) - Restauración desde $ruta_restaurar" >> $log
			else
				echo "[ERROR] Archivo $archivo no se encontró en $destino."
			fi
			;;

		0) echo "Salida exitosa del menú de Respaldos." ;;
		*) echo "Opción inválida." ;;
	esac
done
