#!/bin/bash
log="/var/log/adminsuite.log"
reporte="/adminsuitex/reportes/usuarios_grupos"

op=99
while [ $op -ne 0 ]
do
    echo ""
    echo "*-*-* Usuarios y Grupos *-*-*"
    echo "1 - Crear usuario"
    echo "2 - Eliminar usuario"
    echo "3 - Modificar usuario"
    echo "4 - Agregar/Quitar a grupo"
    echo "5 - Listar usuarios y grupos"
    echo "6 - Buscar por patrón"
    echo "7 - Exportar reporte con fecha"
    echo "0 - Volver"
    read -p "Ingrese una opción: " op

    case $op in
        1)
            read -p "Nombre de usuario: " nombre
            sudo adduser "$nombre"
            echo "Usuario creado: $nombre"
            echo "$(date) - Usuario creado: $nombre" >> "$log"
            ;;

        2)
            read -p "Usuario a eliminar: " nombre
            sudo userdel "$nombre"
            echo "Usuario eliminado: $nombre"
            echo "$(date) - Usuario eliminado: $nombre" >> "$log"
            ;;

        3)
            read -p "Usuario actual: " viejo
            read -p "Nuevo nombre: " nuevo
            sudo usermod -l "$nuevo" "$viejo"
            echo "Usuario renombrado: de $viejo a $nuevo"
            echo "$(date) - Usuario renombrado: de $viejo a $nuevo" >> "$log"
            ;;

        4)
            read -p "Usuario: " usuario
            read -p "Grupo: " grupo
            read -p "Agregar (a) o quitar (q): " opcionug
            
            if [ "$opcionug" = "a" ] || [ "$opcionug" = "A" ]; then
                sudo usermod -aG "$grupo" "$usuario"
                echo "Agregado $usuario al grupo $grupo"
                echo "$(date) - Agregado $usuario al grupo $grupo" >> "$log"
            
            elif [ "$opcionug" = "q" ] || [ "$opcionug" = "Q" ]; then
                sudo deluser "$usuario" "$grupo"
                echo "Quitado $usuario del grupo $grupo"
                echo "$(date) - Quitado $usuario del grupo $grupo" >> "$log"
            
            else
                echo "La opción '$opcionug' es inválida."
                echo "$(date) - [AVISO] La opción '$opcionug' es inválida. No se realizó ninguna acción." >> "$log"
            fi
            ;;

        5)
            echo "Usuarios del sistema:"
            cut -d: -f1 /etc/passwd
            echo ""
            echo "Grupos del sistema:"
            cut -d: -f1 /etc/group
            ;;

        6)
            read -p "Buscar: " patron
            grep "$patron" /etc/passwd
            ;;

        7)
	    sudo mkdir -p "$reporte"
            archivo="reporte_usuarios_grupos_$(date +%Y%m%d).txt"
	    ruta="$reporte/$archivo"
            cut -d: -f1 /etc/passwd > "$ruta"
            cut -d: -f1 /etc/group >> "$ruta"
            echo "Reporte exportado: $archivo"
            echo "$(date) - Reporte exportado ($ruta)" >> "$log"
            ;;

        0) echo "Salida exitosa del menú de Usuarios/Grupos." ;;
        *) echo "Opción inválida." ;;
    esac
done
