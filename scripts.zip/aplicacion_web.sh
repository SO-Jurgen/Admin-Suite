#!/bin/bash
log="/var/log/adminsuite.log"
backup="/adminsuitex/backups/app"

op=99
while [ $op -ne 0 ]
do
	echo ""
	echo "*-*-* Aplicación Web (WordPress) *-*-*"
	echo "1 - Instalar (Docker)"
	echo "2 - Actualizar"
	echo "3 - Ver estado"
	echo "4 - Backup/Restore solo app"
	echo "0 - Volver"
	read -p "Ingrese una opción: " op

	case $op in
		1)
			sudo sed -i 's/mirror.centos.org/vault.centos.org/g' /etc/yum.repos.d/CentOS-*.repo
			sudo sed -i 's/^#baseurl=http/baseurl=http/g' /etc/yum.repos.d/CentOS-*.repo
			sudo sed -i 's/^mirrorlist=http/#mirrorlist=http/g' /etc/yum.repos.d/CentOS-*.repo
			sudo yum clean all
			sudo yum update -y
			sudo yum install -y yum-utils device-mapper-persistent-data lvm2
			sudo yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
			sudo yum install -y docker-ce docker-ce-cli containerd.io
			
			if which docker; then
				sudo systemctl start docker
				sudo systemctl enable docker
				sudo docker run -d -p 8080:80 --name wp wordpress
                                sudo docker update --restart always wp
				echo "¡WordPress instalado exitosamente!"
				echo "$(date) - WordPress instalado con Docker" >> "$log"
			else
				echo "Error: Docker no pudo ser instalado."
				echo "$(date) - [ERROR] Falló la instalación de Docker." >> "$log"
			fi
			;;

		2)
			if sudo docker ps -a --filter name=wp | grep -q wp; then
				sudo docker stop wp
				sudo docker rm wp
			else
				echo "El contenedor 'wp' no se encontró o no estaba corriendo."
			fi
			
			sudo docker pull wordpress:latest
			sudo docker run -d -p 8080:80 --name wp wordpress
			
			echo ""
			echo "¡WordPress actualizado exitosamente!"
			echo "$(date) - WordPress actualizado a la última imagen de Docker" >> "$log"
			;;

		3)
			echo "--- Estado del Contenedor Docker (WordPress) ---"
			sudo docker ps
			;;

		4)
			read -p "¿Backup (b) o Restore (r)?: " opcionbr
			
			if sudo docker ps -a --filter name=wp | grep -q wp; then
			
				if [ "$opcionbr" = "b" ] || [ "$opcionbr" = "B" ]; then
					sudo mkdir -p "$backup"
					sudo docker cp wp:/var/www/html/wp-content ./wp-carpeta
					sudo tar -czf "$backup/wp-backup-$(date +%Y%m%d).tar.gz" ./wp-carpeta
					sudo rm -rf ./wp-carpeta
					echo "Backup creado."
					echo "$(date) - Backup WordPress (Docker) creado" >> "$log"
				
				elif [ "$opcionbr" = "r" ] || [ "$opcionbr" = "R" ]; then
					read -p "Ruta y nombre del archivo a restaurar: " archivo
					
					if [ -f "$archivo" ]; then
						sudo mkdir ./wp-carpeta
						sudo tar -xzf "$archivo" -C ./wp-carpeta
						sudo docker cp ./wp-carpeta/wp-content wp:/var/www/html/
						sudo rm -rf ./wp-carpeta
						echo "Restauración del contenido completada desde $archivo."
						echo "$(date) - WordPress (Docker) restaurado desde $archivo" >> "$log"
					else
						echo "Error: El archivo $archivo no existe."
					fi
				else
					echo "Opción de backup/restore inválida."
				fi
			
			else
				echo "Error: El contenedor 'wp' no existe. Instale WordPress primero (Opción 1)."
			fi
			;;

		0) echo "Salida exitosa del menú de Aplicación Web." ;;
		*) echo "Opción inválida." ;;
	esac
done
