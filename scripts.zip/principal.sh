#!/bin/bash
op=99
while [ $op -ne 0 ]
do
	clear
	echo "*-*-*-*-*-* Admin Suite *-*-*-*-*-*"
	echo "1 - Usuarios y Grupos"
	echo "2 - Aplicación Web"
	echo "3 - Respaldos Programados"
	echo "4 - Logs y Reportes"
	echo "5 - Herramientas de Red"
	echo "6 - Sistema"
	echo "7 - Ayuda"
	echo "0 - Salir"
	echo "*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*"
	read -p "Ingrese una opción: " op

	case $op in
		1) bash usuarios_grupos.sh ;;
		2) bash aplicacion_web.sh ;;
		3) bash respaldos.sh ;;
		4) bash logs_reportes.sh ;;
		5) bash red.sh ;;
		6) bash sistema.sh ;;
		7) bash ayuda.sh ;;
		0) echo "Saliendo...";;
		*) echo "Opción no válida." ;;
	esac
done

